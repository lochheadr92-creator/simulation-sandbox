#!/usr/bin/env python3
"""
Verification evidence gate for Claude Code sessions.

One script, three modes, wired to three events:

  edit    PostToolUse on Edit|Write|MultiEdit|NotebookEdit
          Records that source was mutated this session.

  verify  PostToolUse on Bash
          If the command looks like a test/verification run, records it
          and whether the output looked clean.

  gate    Stop
          Blocks the turn from ending if source was mutated and no clean
          verification run happened AFTER the last mutation.

State lives in .claude/state/<session_id>.json and is per session.

Honest limits, read these:
  - This is a discipline mechanism, not a security boundary. The agent can
    write files, so it could in principle forge state. It cannot do so by
    accident, which is the failure mode this actually targets.
  - Clean/dirty detection reads the Bash tool response for failure markers.
    A test runner with unusual output can be misread. Tune FAILURE_MARKERS.
  - Escape hatch: create .claude/state/verify-exempt to disable the gate.
"""

import json
import os
import re
import sys
import time
from pathlib import Path

DEFAULT_CONFIG = {
    # Substrings that mark a Bash command as a verification run.
    "verify_commands": [
        "pytest",
        "python -m pytest",
        "uv run pytest",
        "poetry run pytest",
        "tox",
        "npm test",
        "npm run test",
        "pnpm test",
        "yarn test",
        "vitest",
        "jest",
        "cargo test",
        "go test",
        "dotnet test",
        "make test",
        "make check",
    ],
    # File extensions that count as source. Everything else is ignored.
    "tracked_extensions": [
        ".py", ".ts", ".tsx", ".js", ".jsx", ".rs", ".go",
        ".cs", ".java", ".rb", ".c", ".h", ".cpp", ".hpp",
    ],
    # Path fragments that exempt a file even if the extension matches.
    "ignored_path_fragments": [
        "/.claude/", "\\.claude\\",
        "/node_modules/", "\\node_modules\\",
        "/.venv/", "\\.venv\\",
    ],
    # Consecutive blocks allowed before the gate warns instead of blocking.
    # Resets on any clean verification run. Prevents an unbreakable loop.
    "max_blocks_per_session": 3,
}

FAILURE_MARKERS = [
    "failed", "FAILED", "ERROR", "error:", "Traceback",
    "AssertionError", "exit code 1", "exit status 1",
    "Tests failed", "FAIL ",
]


def project_dir() -> Path:
    return Path(os.environ.get("CLAUDE_PROJECT_DIR", os.getcwd()))


def load_config() -> dict:
    cfg = dict(DEFAULT_CONFIG)
    path = project_dir() / ".claude" / "hooks" / "evidence-config.json"
    if path.exists():
        try:
            cfg.update(json.loads(path.read_text(encoding="utf-8")))
        except Exception:
            pass  # A broken config must never break the session.
    return cfg


def state_path(session_id: str) -> Path:
    d = project_dir() / ".claude" / "state"
    d.mkdir(parents=True, exist_ok=True)
    safe = re.sub(r"[^A-Za-z0-9_.-]", "_", session_id or "unknown")
    return d / f"{safe}.json"


def read_state(path: Path) -> dict:
    if not path.exists():
        return {"edits": [], "verifies": [], "blocks": 0}
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return {"edits": [], "verifies": [], "blocks": 0}


def write_state(path: Path, state: dict) -> None:
    tmp = path.with_suffix(".tmp")
    tmp.write_text(json.dumps(state, indent=2), encoding="utf-8")
    tmp.replace(path)


def is_tracked_source(file_path: str, cfg: dict) -> bool:
    if not file_path:
        return False
    norm = file_path.replace("\\", "/")
    for frag in cfg["ignored_path_fragments"]:
        if frag.replace("\\", "/") in norm:
            return False
    return any(norm.endswith(ext) for ext in cfg["tracked_extensions"])


def looks_like_verify(command: str, cfg: dict) -> bool:
    low = (command or "").lower()
    return any(token.lower() in low for token in cfg["verify_commands"])


def looks_clean(tool_response) -> bool:
    text = tool_response if isinstance(tool_response, str) else json.dumps(tool_response or "")
    return not any(marker in text for marker in FAILURE_MARKERS)


def mode_edit(payload: dict, cfg: dict) -> int:
    tool_input = payload.get("tool_input") or {}
    path = tool_input.get("file_path") or tool_input.get("notebook_path") or ""
    if not is_tracked_source(path, cfg):
        return 0
    sp = state_path(payload.get("session_id", ""))
    state = read_state(sp)
    state["edits"].append({"ts": time.time(), "path": path})
    write_state(sp, state)
    return 0


def mode_verify(payload: dict, cfg: dict) -> int:
    tool_input = payload.get("tool_input") or {}
    command = tool_input.get("command", "")
    if not looks_like_verify(command, cfg):
        return 0
    clean = looks_clean(payload.get("tool_response"))
    sp = state_path(payload.get("session_id", ""))
    state = read_state(sp)
    state["verifies"].append({"ts": time.time(), "cmd": command, "clean": clean})
    if clean:
        # Budget is per unverified episode, not per session.
        state["blocks"] = 0
    write_state(sp, state)
    return 0


def mode_gate(payload: dict, cfg: dict) -> int:
    if payload.get("stop_hook_active"):
        return 0  # Already re-entered once; never loop.

    if (project_dir() / ".claude" / "state" / "verify-exempt").exists():
        return 0

    sp = state_path(payload.get("session_id", ""))
    state = read_state(sp)

    edits = state.get("edits", [])
    if not edits:
        return 0  # Read-only session. Nothing to verify.

    last_edit = max(e["ts"] for e in edits)
    clean_after = [
        v for v in state.get("verifies", [])
        if v.get("clean") and v.get("ts", 0) > last_edit
    ]
    if clean_after:
        return 0

    blocks = state.get("blocks", 0)
    if blocks >= cfg["max_blocks_per_session"]:
        print(json.dumps({
            "systemMessage": (
                "Verification gate: still no clean test run after the last edit, "
                "but the block limit is reached. Allowing stop. Check manually."
            )
        }))
        return 0

    state["blocks"] = blocks + 1
    write_state(sp, state)

    dirty = sorted({e["path"] for e in edits})[:10]
    stale = [v for v in state.get("verifies", []) if v.get("ts", 0) <= last_edit]
    failed = [v for v in state.get("verifies", []) if not v.get("clean")]

    lines = [
        "VERIFICATION GATE: source was modified this session with no clean test run afterwards.",
        "",
        "Modified files:",
    ]
    lines += [f"  - {p}" for p in dirty]
    if len(edits) > len(dirty):
        lines.append(f"  ... and {len(edits) - len(dirty)} more edits")
    lines.append("")
    if failed:
        lines.append(f"Last verification run reported failures: {failed[-1]['cmd']}")
    elif stale:
        lines.append(f"Last verification run predates the final edit: {stale[-1]['cmd']}")
    else:
        lines.append("No verification run was detected at all this session.")
    lines += [
        "",
        "Run the test suite now and report the actual result. Do not claim the work",
        "is complete or verified until a run has passed after the final edit.",
        "If verification is genuinely not applicable, say so explicitly and explain why.",
    ]
    print("\n".join(lines), file=sys.stderr)
    return 2


def main() -> int:
    mode = sys.argv[1] if len(sys.argv) > 1 else ""
    try:
        payload = json.load(sys.stdin)
    except Exception:
        return 0  # Never break a session on malformed input.

    cfg = load_config()
    if mode == "edit":
        return mode_edit(payload, cfg)
    if mode == "verify":
        return mode_verify(payload, cfg)
    if mode == "gate":
        return mode_gate(payload, cfg)
    return 0


if __name__ == "__main__":
    try:
        sys.exit(main())
    except SystemExit:
        raise
    except Exception as exc:  # Fail open, loudly.
        print(f"evidence.py internal error: {exc}", file=sys.stderr)
        sys.exit(0)
