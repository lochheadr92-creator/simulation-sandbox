#!/usr/bin/env python3
"""
Staging guard for Claude Code.

Wired to PreToolUse on Bash. Blocks bulk-staging and history-destroying git
commands so explicit-path-only staging stops depending on the agent remembering.

Exit 2 blocks the tool call and feeds stderr back to the model as the reason.

Honest limits:
  - Command splitting is a heuristic. Deep shell nesting, eval, or a command
    read from a variable can evade it. This targets the ordinary case, which
    is where the damage actually comes from.
  - It does not stop you running these yourself in a terminal. That is fine:
    the guard exists to constrain the agent, not you.
"""

import json
import re
import sys

# (compiled pattern, human explanation, suggested alternative)
RULES = [
    (
        r"\bgit\s+add\s+(-A\b|--all\b|\.\s*$|\.\s|-u\b|--update\b|\*)",
        "bulk staging (git add . / -A / -u / *)",
        "Stage explicit paths only: git add path/to/file.py path/to/other.py",
    ),
    (
        r"\bgit\s+commit\b[^\n]*(?:^|\s)-[a-zA-Z]*a[a-zA-Z]*(?=\s|$)",
        "git commit -a stages every tracked modification implicitly",
        "Stage explicit paths first, then commit without -a",
    ),
    (
        r"--no-verify\b",
        "--no-verify skips the commit hooks that enforce project invariants",
        "Fix what the hook is complaining about instead of bypassing it",
    ),
    (
        r"\bgit\s+reset\s+--hard\b",
        "git reset --hard destroys uncommitted work irreversibly",
        "Use git stash, or reset specific paths, or ask the user first",
    ),
    (
        r"\bgit\s+checkout\s+(--\s+)?\.\s*$",
        "git checkout . discards all uncommitted changes",
        "Restore specific paths: git checkout -- path/to/file",
    ),
    (
        r"\bgit\s+restore\s+(--\s+)?\.\s*$",
        "git restore . discards all uncommitted changes",
        "Restore specific paths: git restore path/to/file",
    ),
    (
        r"\bgit\s+clean\s+-[a-zA-Z]*[fd]",
        "git clean deletes untracked files, including ones never backed up",
        "List them first with git clean -n and delete specific paths",
    ),
    (
        r"\bgit\s+push\b(?![^\n]*--force-with-lease)[^\n]*(--force\b|-f\b)",
        "force push without --force-with-lease can destroy remote history",
        "Use git push --force-with-lease, and confirm with the user first",
    ),
    (
        r"\bgit\s+(branch\s+-D|update-ref\s+-d|reflog\s+expire)",
        "destructive ref manipulation",
        "Confirm with the user before removing refs or reflog entries",
    ),
]

COMPILED = [(re.compile(p), why, alt) for p, why, alt in RULES]

SPLIT = re.compile(r"&&|\|\||;|\n|\|")


def segments(command: str):
    for raw in SPLIT.split(command or ""):
        seg = raw.strip()
        if seg:
            yield seg


def main() -> int:
    try:
        payload = json.load(sys.stdin)
    except Exception:
        return 0

    command = (payload.get("tool_input") or {}).get("command", "")
    if not command:
        return 0

    for seg in segments(command):
        for pattern, why, alt in COMPILED:
            if pattern.search(seg):
                print(
                    "STAGING GUARD: blocked.\n\n"
                    f"Command segment: {seg}\n"
                    f"Reason: {why}\n"
                    f"Alternative: {alt}\n\n"
                    "This project uses explicit-path-only staging. If this command is "
                    "genuinely required, stop and ask the user to run it themselves.",
                    file=sys.stderr,
                )
                return 2
    return 0


if __name__ == "__main__":
    try:
        sys.exit(main())
    except SystemExit:
        raise
    except Exception as exc:
        print(f"staging_guard.py internal error: {exc}", file=sys.stderr)
        sys.exit(0)
