#!/usr/bin/env python3
"""
Code / golden-fixture separation guard.

Rejects any commit that touches BOTH engine code and golden or fixture data,
unless the commit message carries an explicit override token.

Why commit-msg and not pre-commit: the override token lives in the message,
and pre-commit runs before the message exists. At commit-msg time the index is
still intact, so `git diff --cached` still works. Same enforcement point in
practice, one stage later.

Override, when a fixture genuinely must change alongside code:

    git commit -m "8C-P1: reorder cap eviction

    [fixture-override: eviction ordering changed, golden regenerated and
    diffed by hand, see leg contract section 4]"

The override demands a written reason. That is the point: it converts a silent
reflex into a recorded decision.

Pattern syntax is fnmatch against the forward-slash path from the repo root.
`*` crosses directory boundaries, so `tests/golden/*` matches nested files.
"""

import fnmatch
import json
import re
import subprocess
import sys
from pathlib import Path

DEFAULT_CONFIG = {
    "fixture_globs": [
        "*/golden/*",
        "golden/*",
        "*/fixtures/*",
        "fixtures/*",
        "*/snapshots/*",
        "*/__snapshots__/*",
        "tests/data/*",
        "*.golden",
        "*.golden.json",
        "*.snap",
        "*.approved.txt",
    ],
    "code_extensions": [
        ".py", ".ts", ".tsx", ".js", ".jsx", ".rs", ".go",
        ".cs", ".java", ".rb", ".c", ".h", ".cpp", ".hpp",
    ],
    # Code paths exempt from the rule: test harness plumbing, tooling, etc.
    "code_exempt_globs": [
        ".githooks/*",
        ".claude/*",
        "scripts/*",
        "tools/*",
    ],
    "override_token": "fixture-override:",
}


def repo_root() -> Path:
    out = subprocess.run(
        ["git", "rev-parse", "--show-toplevel"],
        capture_output=True, text=True, check=True,
    )
    return Path(out.stdout.strip())


def load_config(root: Path) -> dict:
    cfg = dict(DEFAULT_CONFIG)
    path = root / ".githooks" / "fixture-guard.json"
    if path.exists():
        try:
            cfg.update(json.loads(path.read_text(encoding="utf-8")))
        except Exception as exc:
            print(f"fixture-guard: config unreadable, using defaults ({exc})", file=sys.stderr)
    return cfg


def staged_files() -> list:
    out = subprocess.run(
        ["git", "diff", "--cached", "--name-only", "--diff-filter=ACMR"],
        capture_output=True, text=True, check=True,
    )
    return [line.strip() for line in out.stdout.splitlines() if line.strip()]


def matches_any(path: str, globs: list) -> bool:
    return any(fnmatch.fnmatch(path, g) for g in globs)


def classify(files: list, cfg: dict):
    fixtures, code = [], []
    for f in files:
        p = f.replace("\\", "/")
        if matches_any(p, cfg["fixture_globs"]):
            fixtures.append(p)
        elif matches_any(p, cfg["code_exempt_globs"]):
            continue
        elif any(p.endswith(ext) for ext in cfg["code_extensions"]):
            code.append(p)
    return code, fixtures


def main() -> int:
    if len(sys.argv) < 2:
        return 0  # Not invoked as commit-msg; do nothing.

    try:
        root = repo_root()
        files = staged_files()
    except subprocess.CalledProcessError:
        return 0  # Not a git repo, or git unavailable. Fail open.

    cfg = load_config(root)
    code, fixtures = classify(files, cfg)

    if not (code and fixtures):
        return 0

    try:
        message = Path(sys.argv[1]).read_text(encoding="utf-8", errors="replace")
    except Exception:
        message = ""

    token = cfg["override_token"]
    override = re.search(re.escape(token) + r"\s*\S+", message, re.IGNORECASE)
    if override:
        reason = message[override.start():].strip().splitlines()[0]
        if len(reason) < len(token) + 15:
            print(
                "fixture-guard: override present but the reason is too short.\n"
                f"Write an actual reason after '{token}'.",
                file=sys.stderr,
            )
            return 1
        return 0

    print("", file=sys.stderr)
    print("FIXTURE GUARD: commit rejected.", file=sys.stderr)
    print("", file=sys.stderr)
    print("This commit changes engine code and golden/fixture data together.", file=sys.stderr)
    print("That is how a defect gets baked into the expected output.", file=sys.stderr)
    print("", file=sys.stderr)
    print("  Code:", file=sys.stderr)
    for f in code[:15]:
        print(f"    {f}", file=sys.stderr)
    if len(code) > 15:
        print(f"    ... and {len(code) - 15} more", file=sys.stderr)
    print("  Fixtures:", file=sys.stderr)
    for f in fixtures[:15]:
        print(f"    {f}", file=sys.stderr)
    if len(fixtures) > 15:
        print(f"    ... and {len(fixtures) - 15} more", file=sys.stderr)
    print("", file=sys.stderr)
    print("Do one of these:", file=sys.stderr)
    print("  1. Commit the code change alone, watch the golden test fail, and", file=sys.stderr)
    print("     confirm the failure is the one you expected. Then commit the", file=sys.stderr)
    print("     regenerated fixture as a separate commit.", file=sys.stderr)
    print("  2. If they genuinely must ship together, add a reason to the", file=sys.stderr)
    print(f"     commit message:  [{cfg['override_token']} why this is correct]", file=sys.stderr)
    print("", file=sys.stderr)
    return 1


if __name__ == "__main__":
    try:
        sys.exit(main())
    except Exception as exc:
        print(f"fixture-guard internal error, allowing commit: {exc}", file=sys.stderr)
        sys.exit(0)
