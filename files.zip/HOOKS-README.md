# Simulation-sandbox hooks: verification gate, staging guard, fixture guard

Three enforcement points. Each targets a failure mode that has already cost you time.

| # | Hook | Event | Blocks |
|---|------|-------|--------|
| 1 | Verification evidence gate | Claude Code `Stop` | Ending a turn after editing source with no clean test run afterwards |
| 2 | Staging guard | Claude Code `PreToolUse` on Bash | `git add .`, `-A`, `-u`, `commit -a`, `--no-verify`, `reset --hard`, `checkout .`, `clean -fd`, bare force push |
| 6 | Code/fixture separation | git `commit-msg` | Any commit touching engine code and golden/fixture data together, without a written override |

## Install

Copy into the repo root, preserving structure:

```
.claude/settings.json
.claude/hooks/evidence.py
.claude/hooks/evidence-config.json
.claude/hooks/staging_guard.py
.githooks/commit-msg
.githooks/fixture_guard.py
.githooks/fixture-guard.json
```

Then, from the repo root:

```
git config core.hooksPath .githooks
git update-index --chmod=+x .githooks/commit-msg     # if git reports it non-executable
```

Add to `.gitignore`:

```
.claude/state/
```

Commit `.claude/settings.json`, the two hook directories, and both config files. Session state is machine-local and must not be tracked.

Restart Claude Code, then run `/hooks` to confirm all four handlers are listed under source `Project`.

## Verify the install

```
# Hook 2 should block this and print a reason:
#   ask Claude to run:  git add .

# Hook 6:
touch engine/anything.py tests/golden/anything.golden.json
git add engine/anything.py tests/golden/anything.golden.json
git commit -m "test"        # expect: FIXTURE GUARD: commit rejected

# Hook 1: have Claude edit any tracked source file and then try to wrap up
# without running tests. Expect the turn to continue with a gate message.
```

## Tuning

`.claude/hooks/evidence-config.json`

- `verify_commands` — substrings that mark a Bash command as a verification run. Add your actual invariant-suite and probe commands here. This is the single most important field; if your real test command is missing, the gate fires constantly.
- `tracked_extensions` — which file types count as source.
- `ignored_path_fragments` — paths exempt from tracking.
- `max_blocks_per_session` — consecutive blocks before the gate downgrades to a warning. Resets on any clean verification run. Default 3.

`.githooks/fixture-guard.json`

- `fixture_globs` — fnmatch patterns against the forward-slash path from repo root. Note that `*` crosses directory separators here, so `*/golden/*` matches at any depth.
- `code_exempt_globs` — code paths the rule ignores (tooling, scripts, the hooks themselves).
- `override_token` — default `fixture-override:`. The reason after it must be at least 15 characters, so the override cannot become a reflex.

## Escape hatches

- Verification gate: `touch .claude/state/verify-exempt` disables it for the repo. Delete the file to re-enable.
- All Claude Code hooks: `"disableAllHooks": true` in `.claude/settings.local.json`.
- Git hooks: `git config --unset core.hooksPath`.

There is deliberately no `--no-verify` path, since hook 2 blocks that flag anyway.

## Known limits, stated plainly

- **The verification gate is discipline, not security.** The agent can write files, so it could in principle forge the evidence record. It will not do so by accident, and accident is the failure mode this targets.
- **Clean/dirty detection is heuristic.** It scans the Bash tool response for failure markers. A test runner with unusual output can be misread in either direction. Watch it for a week and tune `FAILURE_MARKERS` in `evidence.py`.
- **Command splitting in the staging guard is heuristic.** Deeply nested subshells, `eval`, or a command assembled from a variable can evade it. It covers the ordinary case, which is where the damage comes from.
- **Hook 6 runs at `commit-msg`, not `pre-commit`.** The override token lives in the commit message and does not exist yet at pre-commit time. The index is still intact at commit-msg, so `git diff --cached` gives the same file list. Same enforcement, one stage later.
- **All hooks fail open on internal error.** A crashed hook prints to stderr and allows the action. A guard that bricks the repo trains you to disable it, which is worse than no guard.

## Windows note

`.claude/settings.json` uses exec form with `"command": "python"`. If `python` is not on your PATH but the `py` launcher is, change `"command"` to `"py"` in all four handlers. The git `commit-msg` shim already tries `python3`, `python`, then `py` in order.

## What to watch for

The metric that matters is not how often these fire. It is whether you find yourself reaching for the escape hatches. If you disable one within the first fortnight, the hook was wrong, not you: bring back the reason and adjust the config rather than removing the hook.
